# UNTIL 0.2.0 proof bundle

## Repository product cycle

`repository-run.json` records a deterministic control-plane run: six role-separated tasks change `src/activation.js`; the real Node regression test moves from exit 1 to exit 0 / ACTIVATION_TEST_OK; six independent acceptance checks pass; two explicitly allowed files are packaged into an immutable local release candidate. This is not production deployment, an LLM-quality test or a business-outcome claim.

`proof.json` contains 14 deterministic proof checks and `tests.json` contains the complete unit/integration test report.

## Same-model comparison

48 real local-model trials: two software versions, selection and held-out suites, UNTIL and single-prompt arms, three repetitions per task. The held-out UNTIL result changed from 0/6 to 6/6 independently accepted JSON artifacts. The current single prompt also accepted 6/6 and was 3.281x faster, using one model call instead of three.

These are bounded structured-deliverable fixtures, not production code, competitor rankings, business outcomes or a team-replacement study. Local provider charges exclude hardware and electricity. Both current arms received strict JSON schemas; the improvement cannot be attributed to the outer loop alone.

`comparison.json` contains all summaries and trial metadata. Each trial includes the engine result and raw HTTP response content. `manifest.json` records SHA-256 for every other file.

Re-run with Node.js 24+ and the same local Ollama model using `npm run compare -- --label LABEL --system until|direct --suite selection|heldout --repeat 3`, then `npm run compare:report`. Do not mix new runs with the published historical labels.
